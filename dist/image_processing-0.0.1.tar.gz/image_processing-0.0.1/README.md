# image_processing

## Descrição
O pacote image_processing é usado para:

    Processamento:
        - Correspondência de histograma
        - Similaridade estrutural
        - Redimensionar imagem
    Utilitários:
        - Ler imagem
        - Salvar imagem
        - Plotar imagem
        - Plotar resultado
        - Plotar histograma

## Instalação

Use o gerenciador de pacotes [pip](https://pip.pypa.io/en/stable/) para instalar o image_processing

```bash
pip install image_processing
```

## Autor
Gabriel Martins Braulino

## License
[MIT](https://choosealicense.com/licenses/mit/)